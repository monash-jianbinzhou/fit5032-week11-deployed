import { createApp } from 'vue'
import App from './App.vue'
import router from './router'
// Import the functions you need from the SDKs you need
import { initializeApp } from 'firebase/app'
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

//import './assets/main.css'
import 'bootstrap/dist/css/bootstrap.min.css'
//import './style.css'

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: 'AIzaSyBLo8o1UKAIxVs2OnSeMYeU-WSFRq6XHGM',
  authDomain: 'fit5032-mainproject.firebaseapp.com',
  projectId: 'fit5032-mainproject',
  storageBucket: 'fit5032-mainproject.appspot.com',
  messagingSenderId: '651117828142',
  appId: '1:651117828142:web:b52eceb2fe2b8a7b6867bf',
  measurementId: 'G-QFKL7K4PS4'
}

// Initialize Firebase
initializeApp(firebaseConfig)
createApp(App).use(router).mount('#app')
