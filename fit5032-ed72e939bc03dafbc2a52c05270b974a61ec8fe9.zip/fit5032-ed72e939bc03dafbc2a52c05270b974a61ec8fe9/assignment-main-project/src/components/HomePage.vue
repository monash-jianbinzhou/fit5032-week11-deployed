<script>
import { ref, onMounted } from 'vue'
import axios from 'axios'

const phoneNumber = ref('Any question? Please contact us 049xxxxxxx!')
const slogan = ref('Silvercare Hub support the community well-being!')
const mission = ref([
  'Provide reliable health information and telehealth counselling services, especially for older people in remote areas.',
  'Organise and promote age-friendly community activities to facilitate social interaction and reduce isolation.',
  'Integrate various types of resources, including emergency assistance, volunteer services and donation channels, to provide all-round support for the elderly.',
  'Through the user account management function, seniors can conveniently book medical appointments and participate in community activities, and for those who do not know how to use the website, volunteers will also provide technical assistance or accept phone appointments.'
])

const organizationInfo = ref({
  name: 'Silvercare Hub',
  address: '123 Care Street',
  city: 'Melbourne',
  phone: '049xxxxxxx',
  openingHours: 'Mon-Fri: 9AM-5PM'
})

export default {
  name: 'HomePage',
  setup() {
    onMounted(() => {
      // Ensure that the mapboxgl object is available using a global variable
      if (window.mapboxgl) {
        window.mapboxgl.accessToken =
          'pk.eyJ1IjoiamlhbmJpbnpob3UiLCJhIjoiY2x6aHF1amJmMDc2bTJrcTJxY2lubnBxeiJ9.vQZhyROyZYPlAlVahk4HHA'
        const map = new window.mapboxgl.Map({
          container: 'map',
          style: 'mapbox://styles/mapbox/streets-v11',
          center: [144.9631, -37.8136], // Melbourne coordinates
          zoom: 12
        })

        // Add a marker showing the location of Silvercare Hub
        new window.mapboxgl.Marker().setLngLat([144.9631, -37.8136]).addTo(map)

        // Add Mapbox Directions control
        if (window.MapboxDirections) {
          const directions = new window.MapboxDirections({
            accessToken: window.mapboxgl.accessToken,
            unit: 'metric',
            profile: 'mapbox/driving'
          })

          map.addControl(directions, 'top-left')
        }
      }
    })

    const subscriberEmail = ref('')

    const subscribeNewsletter = async () => {
      try {
        const response = await axios.post(
          'https://api.sendinblue.com/v3/contacts',
          {
            email: subscriberEmail.value,
            listIds: [7], // list id for newsletter subscribers in brevo
            updateEnabled: true
          },
          {
            headers: {
              'api-key':
                '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',
              'Content-Type': 'application/json'
            }
          }
        )
        if (response.status === 201) {
          alert('Subscription successful! Please check your email.')
          subscriberEmail.value = ''
        } else {
          alert('Please check your email.')
        }
      } catch (error) {
        console.error('Error subscribing:', error)
        alert('An error occurred. Please try again later.')
      }
    }

    return {
      phoneNumber,
      slogan,
      mission,
      organizationInfo,
      subscriberEmail,
      subscribeNewsletter
    }
  }
}
</script>

<template>
  <div class="container">
    <div class="col-12">
      <div class="top-banner bg-success text-center py-2">
        {{ phoneNumber }}
      </div>
    </div>

    <div class="col-12 text-center">
      <div class="slogan-container py-4">
        <p class="slogan">{{ slogan }}</p>
        <div class="buttons d-flex justify-content-center gap-2 flex-wrap">
          <button class="btn btn-secondary">
            <router-link to="/about-us">ABOUT US</router-link>
          </button>
          <button class="btn btn-secondary">
            <router-link to="/reg">Get Started</router-link>
          </button>
        </div>
      </div>
    </div>

    <nav class="navbar">
      <div class="logo">
        <a href="#"><img src="../Pic/Silver-Care-Hub-transparent.png" alt="Logo" /></a>
      </div>
      <ul class="nav-links d-flex flex-column flex-md-row">
        <li><router-link to="/">HOME</router-link></li>
        <li><router-link to="/about-us">ABOUT US</router-link></li>
        <li><router-link to="/charity-clinic-service">Free Medical Consult</router-link></li>
        <li><router-link to="/community-events">Events</router-link></li>
        <li><router-link to="/login">Login</router-link></li>
        <li><router-link to="/register">Register</router-link></li>
        <li><router-link to="/user-account">User Account</router-link></li>
      </ul>
    </nav>
    <div class="row my-4">
      <div class="col-12">
        <div class="mission-section">
          <h2 class="text-center">Our Mission</h2>
          <ul class="mission-list">
            <li
              v-for="(item, index) in mission"
              :key="index"
              :class="'mission-card-' + (index + 1)"
            >
              {{ item }}
            </li>
          </ul>
        </div>
      </div>
    </div>

    <div class="row my-4">
      <div class="col-md-8">
        <div id="map" style="height: 400px"></div>
      </div>
      <div class="col-md-4">
        <div class="info-panel">
          <h3>{{ organizationInfo.name }}</h3>
          <p><strong>Address:</strong> {{ organizationInfo.address }}</p>
          <p><strong>City:</strong> {{ organizationInfo.city }}</p>
          <p><strong>Phone:</strong> {{ organizationInfo.phone }}</p>
          <p><strong>Opening Hours:</strong> {{ organizationInfo.openingHours }}</p>
        </div>
      </div>
    </div>

    <div class="row my-4">
      <div class="col-12">
        <div class="subscribe-section">
          <h3>Subscribe to Our Newsletter</h3>
          <form @submit.prevent="subscribeNewsletter">
            <div class="input-group mb-3">
              <input
                type="email"
                v-model="subscriberEmail"
                class="form-control"
                placeholder="Enter your email"
                required
              />
              <button class="btn btn-primary" type="submit">Subscribe</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>
.container {
  background-color: #f9f9f9;
}

.top-banner {
  font-size: 1.2em;
  margin-bottom: 0;
}

.slogan-container {
  background-color: #5e4520;
  margin-top: 0;
}

.slogan {
  color: white;
  font-size: 1.5em;
  margin-bottom: 20px;
}

.navbar {
  background-color: #ffffff;
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 10px 20px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

.logo img {
  height: 40px;
}

.nav-links {
  list-style-type: none;
  display: flex;
  margin: 0;
  padding: 0;
}

.nav-links li {
  margin-left: 20px;
}

.nav-links a {
  color: #000000;
  background-color: #ffffff;
  text-decoration: none;
  font-weight: bold;
  font-size: 14px;
  padding: 10px 15px;
  border-radius: 5px;
  transition: all 0.3s ease;
}

.nav-links a:hover {
  color: #ffffff;
  background-color: #000000;
}

.row.no-gap {
  margin-left: 0;
  margin-right: 0;
}

.mission-section {
  background-color: #f8f9fa;
  border-radius: 8px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

.mission-section h2 {
  color: #333;
  margin-bottom: 20px;
}

.mission-list {
  list-style-type: none;
  padding: 0;
}

.mission-list li {
  border-radius: 5px;
  padding: 15px;
  margin-bottom: 15px;
  color: white;
  font-weight: bold;
  transition: transform 0.3s;
}

.mission-list li:hover {
  transform: scale(1.05);
}

.mission-card-1 {
  background-color: #ff6f61;
}

.mission-card-2 {
  background-color: #6b5b95;
}

.mission-card-3 {
  background-color: #88b04b;
}

.mission-card-4 {
  background-color: #f7cac9;
}

.info-panel {
  background-color: #f8f9fa;
  border-radius: 8px;
  padding: 20px;
  height: 100%;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

.info-panel h3 {
  color: #333;
  margin-bottom: 15px;
}

.info-panel p {
  margin-bottom: 10px;
}

@media (max-width: 768px) {
  #map {
    height: 300px;
    margin-bottom: 20px;
  }
}

.subscribe-section {
  background-color: #f8f9fa;
  border-radius: 8px;
  padding: 20px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

.subscribe-section h3 {
  color: #333;
  margin-bottom: 15px;
}

.subscribe-section .input-group {
  display: flex;
  align-items: center;
}

.subscribe-section input {
  padding: 10px;
  margin-right: 10px;
  border: 1px solid #ccc;
  border-radius: 4px;
  flex: 1;
}

.subscribe-section button {
  padding: 10px 15px;
  background-color: #007bff;
  color: #fff;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

.subscribe-section button:hover {
  background-color: #0056b3;
}
</style>
