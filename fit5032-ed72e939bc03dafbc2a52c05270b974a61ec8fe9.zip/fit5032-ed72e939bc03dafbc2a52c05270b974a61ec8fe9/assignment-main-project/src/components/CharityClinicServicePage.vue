<template>
  <div class="container">
    <nav class="navbar">
      <div class="logo">
        <a href="#"><img src="../Pic/Silver-Care-Hub-transparent.png" alt="Logo" /></a>
      </div>
      <ul class="nav-links d-flex flex-column flex-md-row">
        <li><router-link to="/">HOME</router-link></li>
        <li><router-link to="/about-us">ABOUT US</router-link></li>
        <li><router-link to="/charity-clinic-service">Free Medical Consult</router-link></li>
        <li><router-link to="/community-events">Events</router-link></li>
        <li><router-link to="/login">Login</router-link></li>
        <li><router-link to="/register">Register</router-link></li>
        <li><router-link to="/user-account">User Account</router-link></li>
      </ul>
    </nav>
    <div class="doctors">
      <div class="col-12">
        <h1>Our Doctors</h1>
      </div>
      <div class="row">
        <div
          class="col-sm-12 col-md-6 col-lg-6 col-xl-4"
          v-for="doctor in doctors"
          :key="doctor.name"
        >
          <div class="doctor-card">
            <div class="avatar-placeholder">Avatar</div>
            <h2>{{ doctor.name }}</h2>
            <p><strong>Available Times:</strong> {{ doctor.available_times.join(', ') }}</p>
            <p><strong>Languages Spoken:</strong> {{ doctor.languages_spoken.join(', ') }}</p>
            <p><strong>Specialties:</strong> {{ doctor.specialties.join(', ') }}</p>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import axios from 'axios'

export default {
  name: 'CharityClinicServicePage',
  data() {
    return {
      doctors: []
    }
  },
  created() {
    this.fetchDoctors()
  },
  methods: {
    async fetchDoctors() {
      try {
        const response = await axios.get('/src/assets/json/gp.json')
        this.doctors = response.data
      } catch (error) {
        console.error('Error fetching doctors:', error)
      }
    }
  }
}
</script>

<style scoped>
.container {
  background-color: #f9f9f9;
}

.doctors {
  display: flex;
  flex-wrap: wrap;
  gap: 20px;
  max-width: 800px;
  margin: 0 auto;
  padding: 20px;
}

.doctors h1 {
  display: block;
  text-align: center;
  font-size: 24px;
  margin: 20px 0;
  color: green;
  width: 100%;
  box-sizing: border-box;
  clear: both;
}

.doctor-card {
  flex: 1 1 calc(33.333% - 20px);
  box-sizing: border-box;
  border: 1px solid #ccc;
  border-radius: 8px;
  padding: 20px;
  margin-bottom: 20px;
  display: flex;
  flex-direction: column;
  align-items: center;
}

.avatar-placeholder {
  width: 80px;
  height: 80px;
  background-color: #eee;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  margin-bottom: 20px;
  font-size: 14px;
  color: #aaa;
}

.navbar {
  background-color: #ffffff;
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 10px 20px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

.logo img {
  height: 40px;
}

.nav-links {
  list-style-type: none;
  display: flex;
  margin: 0;
  padding: 0;
}

.nav-links li {
  margin-left: 20px;
}

.nav-links a {
  color: #000000;
  background-color: #ffffff;
  text-decoration: none;
  font-weight: bold;
  font-size: 14px;
  padding: 10px 15px;
  border-radius: 5px;
  transition: all 0.3s ease;
}

.nav-links a:hover {
  color: #ffffff;
  background-color: #000000;
}
</style>
