<template>
  <div class="container">
    <nav class="navbar">
      <div class="logo">
        <a href="#"><img src="../Pic/Silver-Care-Hub-transparent.png" alt="Logo" /></a>
      </div>
      <ul class="nav-links d-flex flex-column flex-md-row">
        <li><router-link to="/">HOME</router-link></li>
        <li><router-link to="/about-us">ABOUT US</router-link></li>
        <li><router-link to="/charity-clinic-service">Free Medical Consult</router-link></li>
        <li><router-link to="/community-events">Events</router-link></li>
        <li><router-link to="/login">Login</router-link></li>
        <li><router-link to="/register">Register</router-link></li>
        <li><router-link to="/user-account">User Account</router-link></li>
      </ul>
    </nav>
    <div class="events">
      <h2>Health Lecture Events</h2>
      <input v-model="searchLecture" placeholder="Search Lecture Events" />
      <table>
        <thead>
          <tr>
            <th @click="sortLecture('event_name')">Event Name</th>
            <th @click="sortLecture('event_datetime')">Date & Time</th>
            <th @click="sortLecture('location')">Location</th>
            <th @click="sortLecture('max_participants')">Max Participants</th>
            <th @click="sortLecture('speaker_name')">Speaker Name</th>
            <th @click="sortLecture('speaker_expertise')">Speaker Expertise</th>
            <th @click="sortLecture('topic')">Topic</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="event in paginatedLectureEvents" :key="event.event_id">
            <td>{{ event.event_name }}</td>
            <td>{{ event.event_datetime }}</td>
            <td>{{ event.location }}</td>
            <td>{{ event.max_participants }}</td>
            <td>{{ event.speaker_name }}</td>
            <td>{{ event.speaker_expertise }}</td>
            <td>{{ event.topic }}</td>
          </tr>
        </tbody>
      </table>
      <button @click="prevPageLecture" :disabled="currentPageLecture === 1">Previous</button>
      <button @click="nextPageLecture" :disabled="currentPageLecture === totalPagesLecture">
        Next
      </button>

      <h2>Health Supply Events</h2>
      <input v-model="searchSupply" placeholder="Search Supply Events" />
      <table>
        <thead>
          <tr>
            <th @click="sortSupply('event_name')">Event Name</th>
            <th @click="sortSupply('event_datetime')">Date & Time</th>
            <th @click="sortSupply('location')">Location</th>
            <th @click="sortSupply('max_participants')">Max Participants</th>
            <th @click="sortSupply('supply_type')">Supply Type</th>
            <th @click="sortSupply('quantity_available')">Quantity Available</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="event in paginatedSupplyEvents" :key="event.event_id">
            <td>{{ event.event_name }}</td>
            <td>{{ event.event_datetime }}</td>
            <td>{{ event.location }}</td>
            <td>{{ event.max_participants }}</td>
            <td>{{ event.supply_type }}</td>
            <td>{{ event.quantity_available }}</td>
          </tr>
        </tbody>
      </table>
      <button @click="prevPageSupply" :disabled="currentPageSupply === 1">Previous</button>
      <button @click="nextPageSupply" :disabled="currentPageSupply === totalPagesSupply">
        Next
      </button>
    </div>
  </div>
</template>

<script>
import { ref, computed } from 'vue'
import eventsLecture from '../assets/json/health_lecture_events.json'
import eventsSupply from '../assets/json/health_supply_events.json'

export default {
  name: 'CommunityEvents',
  setup() {
    const healthLectureEvents = ref(eventsLecture)
    const healthSupplyEvents = ref(eventsSupply)

    const searchLecture = ref('')
    const searchSupply = ref('')

    const currentPageLecture = ref(1)
    const currentPageSupply = ref(1)
    const itemsPerPage = 10

    const sortedLectureEvents = ref([...healthLectureEvents.value])
    const sortedSupplyEvents = ref([...healthSupplyEvents.value])

    const sortLecture = (key) => {
      sortedLectureEvents.value.sort((a, b) => (a[key] > b[key] ? 1 : -1))
    }

    const sortSupply = (key) => {
      sortedSupplyEvents.value.sort((a, b) => (a[key] > b[key] ? 1 : -1))
    }

    const filteredLectureEvents = computed(() => {
      return sortedLectureEvents.value.filter((event) =>
        Object.values(event).some((val) =>
          String(val).toLowerCase().includes(searchLecture.value.toLowerCase())
        )
      )
    })

    const filteredSupplyEvents = computed(() => {
      return sortedSupplyEvents.value.filter((event) =>
        Object.values(event).some((val) =>
          String(val).toLowerCase().includes(searchSupply.value.toLowerCase())
        )
      )
    })

    const paginatedLectureEvents = computed(() => {
      const start = (currentPageLecture.value - 1) * itemsPerPage
      const end = start + itemsPerPage
      return filteredLectureEvents.value.slice(start, end)
    })

    const paginatedSupplyEvents = computed(() => {
      const start = (currentPageSupply.value - 1) * itemsPerPage
      const end = start + itemsPerPage
      return filteredSupplyEvents.value.slice(start, end)
    })
    const totalPagesLecture = computed(() => {
      return Math.ceil(filteredLectureEvents.value.length / itemsPerPage)
    })

    const totalPagesSupply = computed(() => {
      return Math.ceil(filteredSupplyEvents.value.length / itemsPerPage)
    })

    const prevPageLecture = () => {
      if (currentPageLecture.value > 1) currentPageLecture.value--
    }

    const nextPageLecture = () => {
      if (currentPageLecture.value < totalPagesLecture.value) currentPageLecture.value++
    }
    const prevPageSupply = () => {
      if (currentPageSupply.value > 1) currentPageSupply.value--
    }
    const nextPageSupply = () => {
      if (currentPageSupply.value < totalPagesSupply.value) currentPageSupply.value++
    }

    return {
      searchLecture,
      searchSupply,
      paginatedLectureEvents,
      paginatedSupplyEvents,
      sortLecture,
      sortSupply,
      prevPageLecture,
      nextPageLecture,
      prevPageSupply,
      nextPageSupply,
      currentPageLecture,
      currentPageSupply,
      totalPagesLecture,
      totalPagesSupply
    }
  }
}
</script>

<style scoped>
.container {
  background-color: #f9f9f9;
}

.navbar {
  background-color: #ffffff;
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 10px 20px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

.logo img {
  height: 40px;
}

.nav-links {
  list-style-type: none;
  display: flex;
  margin: 0;
  padding: 0;
}

.nav-links li {
  margin-left: 20px;
}

.nav-links a {
  color: #000000;
  background-color: #ffffff;
  text-decoration: none;
  font-weight: bold;
  font-size: 14px;
  padding: 10px 15px;
  border-radius: 5px;
  transition: all 0.3s ease;
}

.nav-links a:hover {
  color: #ffffff;
  background-color: #000000;
}

.events {
  margin-top: 20px;
}

.events h2 {
  font-size: 24px;
  margin-bottom: 10px;
}

.events table {
  width: 100%;
  border-collapse: collapse;
  margin-bottom: 20px;
}

.events th,
.events td {
  border: 1px solid #ddd;
  padding: 8px;
}

.events th {
  cursor: pointer;
  background-color: #f2f2f2;
}

.events th:hover {
  background-color: #ddd;
}

.events input {
  margin-bottom: 10px;
  padding: 8px;
  width: 100%;
  box-sizing: border-box;
}

.events button {
  padding: 10px 15px;
  margin: 5px;
  cursor: pointer;
}
</style>
