<template>
  <div class="container">
    <nav class="navbar">
      <div class="logo">
        <a href="#"><img src="../Pic/Silver-Care-Hub-transparent.png" alt="Logo" /></a>
      </div>
      <ul class="nav-links d-flex flex-column flex-md-row">
        <li><router-link to="/">HOME</router-link></li>
        <li><router-link to="/about-us">ABOUT US</router-link></li>
        <li><router-link to="/charity-clinic-service">Free Medical Consult</router-link></li>
        <li><router-link to="/community-events">Events</router-link></li>
        <li><router-link to="/login">Login</router-link></li>
        <li><router-link to="/reg">Register</router-link></li>
        <li><router-link to="/user-account">User Account</router-link></li>
      </ul>
    </nav>

    <div class="row">
      <div class="col-md-8 offset-md-2">
        <h1 class="text-center">User Information Form</h1>
        <form @submit.prevent="submitForm">
          <div class="row mb-3">
            <div class="col-sm-12 col-md-6">
              <label for="username" class="form-label">Username</label>
              <input type="text" class="form-control" id="username" v-model="formData.username" />
              <div v-if="errors.username" class="text-danger">{{ errors.username }}</div>
            </div>
            <div class="col-sm-12 col-md-6">
              <label for="email" class="form-label">Email</label>
              <input type="email" class="form-control" id="email" v-model="formData.email" />
            </div>
          </div>
          <div class="row mb-3">
            <div class="col-sm-12 col-md-6">
              <label for="password" class="form-label">Password</label>
              <input
                type="password"
                class="form-control"
                id="password"
                v-model="formData.password"
              />
            </div>
          </div>
          <button type="submit" class="btn btn-primary">Save to Firebase</button>
        </form>
        <p v-if="error" class="text-danger">{{ error }}</p>
      </div>
    </div>
  </div>
</template>

<script>
import { ref } from 'vue'
import { getAuth, createUserWithEmailAndPassword } from 'firebase/auth'
import { getFirestore, doc, setDoc } from 'firebase/firestore'
import { useRouter } from 'vue-router'

export default {
  name: 'RegForm',
  setup() {
    const formData = ref({
      username: '',
      email: '',
      password: ''
    })
    const errors = ref({})
    const error = ref('')
    const router = useRouter()
    const auth = getAuth()
    const db = getFirestore()

    const validateForm = () => {
      errors.value = {}
      if (!formData.value.username) errors.value.username = 'Username is required'
      if (!formData.value.email) errors.value.email = 'Email is required'
      if (!formData.value.password) errors.value.password = 'Password is required'
      return Object.keys(errors.value).length === 0
    }

    const submitForm = async () => {
      if (!validateForm()) return

      try {
        const userCredential = await createUserWithEmailAndPassword(
          auth,
          formData.value.email,
          formData.value.password
        )
        const user = userCredential.user

        // Store additional user data in Firestore
        await setDoc(doc(db, 'users', user.uid), {
          username: formData.value.username,
          email: formData.value.email
        })

        alert('Registration successful! You can now log in.')
        router.push('/login')
      } catch (err) {
        console.log(err.code)
        alert(`Registration failed: ${err.message}`)
      }
    }

    return {
      formData,
      errors,
      error,
      submitForm
    }
  }
}
</script>

<style scoped>
.container {
  background-color: #f9f9f9;
}

.navbar {
  background-color: #ffffff;
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 10px 20px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

.logo img {
  height: 40px;
}

.nav-links {
  list-style-type: none;
  display: flex;
  margin: 0;
  padding: 0;
}

.nav-links li {
  margin-left: 20px;
}

.nav-links a {
  color: #000000;
  background-color: #ffffff;
  text-decoration: none;
  font-weight: bold;
  font-size: 14px;
  padding: 10px 15px;
  border-radius: 5px;
  transition: all 0.3s ease;
}

.nav-links a:hover {
  color: #ffffff;
  background-color: #000000;
}

.row {
  margin-top: 20px;
}

.text-center {
  text-align: center;
}

.text-danger {
  color: red;
}

.btn-primary {
  background-color: #007bff;
  border: none;
  padding: 10px 20px;
  color: white;
  cursor: pointer;
  border-radius: 5px;
}

.btn-primary:hover {
  background-color: #0056b3;
}
</style>
