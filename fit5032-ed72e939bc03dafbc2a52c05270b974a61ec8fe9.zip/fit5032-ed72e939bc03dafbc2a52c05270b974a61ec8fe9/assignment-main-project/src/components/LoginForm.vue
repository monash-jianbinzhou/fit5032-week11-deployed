<template>
  <div class="container">
    <nav class="navbar">
      <div class="logo">
        <a href="#"><img src="../Pic/Silver-Care-Hub-transparent.png" alt="Logo" /></a>
      </div>
      <ul class="nav-links d-flex flex-column flex-md-row">
        <li><router-link to="/">HOME</router-link></li>
        <li><router-link to="/about-us">ABOUT US</router-link></li>
        <li><router-link to="/charity-clinic-service">Free Medical Consult</router-link></li>
        <li><router-link to="/community-events">Events</router-link></li>
        <li><router-link to="/login">Login</router-link></li>
        <li><router-link to="/register">Register</router-link></li>
        <li><router-link to="/user-account">User Account</router-link></li>
      </ul>
    </nav>

    <h1>Sign in</h1>
    <p><input type="text" placeholder="Email" v-model="email" /></p>
    <p><input type="password" placeholder="Password" v-model="password" /></p>
    <p><button @click="signin">Sign in via Firebase</button></p>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import { getAuth, signInWithEmailAndPassword } from 'firebase/auth'
import { useRouter } from 'vue-router'

const email = ref('')
const password = ref('')
const router = useRouter()
const auth = getAuth()

const signin = () => {
  signInWithEmailAndPassword(getAuth(), email.value, password.value)
    .then((data) => {
      alert('Login successful!')
      console.log('Firebase Login Successful')
      router.push('/')
      console.log(auth.currentUser) //To check the current User signed in
    })
    .catch((error) => {
      console.log(error.code)
      let errorMessage
      switch (error.code) {
        case 'auth/invalid-email':
          errorMessage = 'Invalid email format'
          break
        case 'auth/user-not-found':
          errorMessage = 'User not found'
          break
        case 'auth/wrong-password':
          errorMessage = 'Incorrect password'
          break
        default:
          errorMessage = 'Login failed, please try again later'
      }
      alert(errorMessage)
    })
}
</script>

<script>
export default {
  name: 'LoginForm'
}
</script>

<style scoped>
.container {
  background-color: #f9f9f9;
}

.navbar {
  background-color: #ffffff;
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 10px 20px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

.logo img {
  height: 40px;
}

.nav-links {
  list-style-type: none;
  display: flex;
  margin: 0;
  padding: 0;
}

.nav-links li {
  margin-left: 20px;
}

.nav-links a {
  color: #000000;
  background-color: #ffffff;
  text-decoration: none;
  font-weight: bold;
  font-size: 14px;
  padding: 10px 15px;
  border-radius: 5px;
  transition: all 0.3s ease;
}

.nav-links a:hover {
  color: #ffffff;
  background-color: #000000;
}
</style>
