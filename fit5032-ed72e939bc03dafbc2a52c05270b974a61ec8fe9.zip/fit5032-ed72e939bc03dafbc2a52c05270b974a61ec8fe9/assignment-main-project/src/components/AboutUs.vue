<script>
import { ref } from 'vue'

export default {
  name: 'AboutUs',
  setup() {
    const phoneNumber = ref('Any question? Please contact us 049xxxxxxx!')
    return {
      phoneNumber
    }
  }
}
</script>

<template>
  <div class="container">
    <div class="col-12">
      <div class="top-banner bg-success text-center py-2">
        {{ phoneNumber }}
      </div>
    </div>

    <nav class="navbar">
      <div class="logo">
        <a href="#"><img src="../Pic/Silver-Care-Hub-transparent.png" alt="Logo" /></a>
      </div>
      <ul class="nav-links d-flex flex-column flex-md-row">
        <li><router-link to="/">HOME</router-link></li>
        <li><router-link to="/about-us">ABOUT US</router-link></li>
        <li><router-link to="/charity-clinic-service">Free Medical Consult</router-link></li>
        <li><router-link to="/community-events">Events</router-link></li>
        <li><router-link to="/login">Login</router-link></li>
        <li><router-link to="/register">Register</router-link></li>
        <li><router-link to="/user-account">User Account</router-link></li>
      </ul>
    </nav>

    <h2 class="text-center">About Us</h2>

    <div class="about-section">
      <h3>Our Mission</h3>
      <p>
        SilverCare Hub is dedicated to the physical and mental health of older people in Victoria.
        As the population ages, the needs of the elderly are growing rapidly.
      </p>
    </div>

    <div class="about-section">
      <h3>Demographic Challenges</h3>
      <p>
        Victoria's older population is approaching 1.5 million, or 22 percent of the total
        population, and is expected to surge to over 2.3 million by 2046. This demographic shift is
        putting enormous pressure on healthcare resources, especially in remote areas.
      </p>
    </div>

    <div class="about-section">
      <h3>Social Needs</h3>
      <p>
        In addition to medical needs, the social needs of the elderly cannot be ignored. Social
        isolation can lead to serious mental health problems, making it important to create
        opportunities for seniors to participate in community activities and maintain social
        connections.
      </p>
    </div>

    <div class="about-section">
      <h3>Our Platform</h3>
      <ul>
        <li>
          Provide reliable health information and telehealth counselling services, especially for
          older people in remote areas.
        </li>
        <li>
          Organise and promote age-friendly community activities to facilitate social interaction
          and reduce isolation.
        </li>
        <li>
          Integrate various types of resources, including emergency assistance, volunteer services,
          and donation channels, to provide all-round support for the elderly.
        </li>
        <li>
          Through the user account management function, seniors can conveniently book medical
          appointments and participate in community activities, with technical assistance available
          for those who need it.
        </li>
      </ul>
    </div>

    <div class="about-section">
      <h3>Our Vision</h3>
      <p>
        SilverCare Hub aims to create a supportive ecosystem that not only meets the healthcare
        needs of older people but also promotes their social engagement and overall well-being,
        thereby helping to overcome the challenges brought by Victoria's growing older population.
      </p>
    </div>
  </div>
</template>

<style scoped>
.container {
  background-color: #f9f9f9;
}

.top-banner {
  font-size: 1.2em;
  margin-bottom: 0;
}

.navbar {
  background-color: #ffffff;
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 10px 20px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

.logo img {
  height: 40px;
}

.nav-links {
  list-style-type: none;
  display: flex;
  margin: 0;
  padding: 0;
}

.nav-links li {
  margin-left: 20px;
}

.nav-links a {
  color: #000000;
  background-color: #ffffff;
  text-decoration: none;
  font-weight: bold;
  font-size: 14px;
  padding: 10px 15px;
  border-radius: 5px;
  transition: all 0.3s ease;
}

.nav-links a:hover {
  color: #ffffff;
  background-color: #000000;
}

.about-section {
  margin: 20px 0;
}

.about-section h3 {
  color: #5e4520;
  font-size: 1.5em;
  margin-bottom: 10px;
}

.about-section p,
.about-section ul {
  color: #333333;
  font-size: 1em;
  line-height: 1.5;
}

.about-section ul {
  list-style-type: disc;
  padding-left: 20px;
}
</style>
