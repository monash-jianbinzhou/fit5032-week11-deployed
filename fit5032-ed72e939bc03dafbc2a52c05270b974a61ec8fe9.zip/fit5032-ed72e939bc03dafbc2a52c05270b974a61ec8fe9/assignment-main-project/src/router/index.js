import { createRouter, createWebHistory } from 'vue-router'
import HomePage from '../components/HomePage.vue'
import AboutUs from '../components/AboutUs.vue'
import CharityClinicServicePage from '../components/CharityClinicServicePage.vue'
import RegForm from '../components/RegForm.vue'
import CommunityEvents from '../components/CommunityEvents.vue'
import LoginForm from '../components/LoginForm.vue'

const routes = [
  { path: '/', component: HomePage },
  { path: '/about-us', component: AboutUs },
  { path: '/charity-clinic-service', component: CharityClinicServicePage },
  { path: '/community-events', component: CommunityEvents },
  { path: '/login', component: LoginForm },
  { path: '/register', component: RegForm }
]

const router = createRouter({
  history: createWebHistory(),
  routes
})

export default router
